﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerPositionReportService.Service
{
    public interface IReportingService: IDisposable
    {
        void GenerateAndScheduleDayAheadPowerPositionReport();
        void GenerateDayAheadPowerPositionReport();
        bool ReportFailed { get; }
        void ScheduleDayAheadPowerPositionReport();
    }
}
