﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using log4net;
using PowerCommon.Data;
using PowerPositionReportService.Reports;
using PowerCommon.Helpers;
using Services;

namespace PowerPositionReportService.Service
{
    public class ReportingService : IReportingService
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IPowerService _powerService;
        private readonly IReport _powerPositionReport;
        private int _inTimerCallback = 0;
        private readonly ManualResetEvent _resetEvent;
        private readonly int _reportFrequency;

        public ReportingService(IPowerService powerService
            ,IReport powerPositionReport
            ,int reportFrequencyInMinutes
            )
        {
            Log.Info("Constructing ReportService");
            _powerService = powerService;
            _powerPositionReport = powerPositionReport;
            _reportFrequency = reportFrequencyInMinutes;
            _resetEvent = new ManualResetEvent(false);
            
        }

        public void GenerateAndScheduleDayAheadPowerPositionReport()
        {
            GenerateDayAheadPowerPositionReport();
            ScheduleDayAheadPowerPositionReport();
        }

        private void TimerCallback(ManualResetEvent resetEvent, ref int inTimerCallback )
        {
            if (Interlocked.Exchange(ref inTimerCallback, 1) != 0)
            {
                return;
            }
            try
            {
                GenerateDayAheadPowerPositionReport();
            }
            catch(Exception e)
            {
                Log.Error("GenerateDayAheadPowerPositionReport failed", e);
                resetEvent.Set();
            }
            finally
            {
                Interlocked.Exchange(ref inTimerCallback, 0);
            }
        }

        public void GenerateDayAheadPowerPositionReport()
        {
            Log.Info("About to run GenerateDayAheadPowerPositionReport");
            var nextTradeDate = GetNextTradeDate();
            var trades = _powerService.GetTrades(nextTradeDate);
            //var trades = _powerService.GetTradesAsync(nextTradeDate).Result;
            var aggTrade = AggregatePowerTrades(trades);
            _powerPositionReport.ExportReport(aggTrade);
            Log.Info("completed GenerateDayAheadPowerPositionReport");

        }

        private DateTime GetNextTradeDate()
        {
            return DateTime.Now.AddDays(1).Date;
        }

        private PowerTrade AggregatePowerTrades(IEnumerable<PowerTrade> powerTrades)
        {
            var agg = powerTrades.Aggregate(
                PowerTrade.Create(powerTrades.First().Date, 25) ,
                
                (total, next) => 
                {
                    foreach(var p in next.Periods)
                    {
                        total.Periods[p.Period-1].Volume  += p.Volume;
                    }

                    return total;
                }

                );
            return agg;
        }

        
        
        public bool ReportFailed => _resetEvent.WaitOne(10);

        public void ScheduleDayAheadPowerPositionReport()
        {
            Log.Info($"Schedling Day ahead power position report");
            var failedTocken = new CancellationTokenSource();
            var timeOfDay = DateTime.Now.TimeOfDay;
            var interval = _reportFrequency - (Math.Floor(timeOfDay.TotalMinutes) % _reportFrequency);
            var nextFullHour = TimeSpan.FromMinutes(Math.Floor(timeOfDay.TotalMinutes) + interval);
            var timeTillNextHour = nextFullHour - timeOfDay;
            var _positionReportScheduler 
                = new Timer(t =>  TimerCallback(_resetEvent, ref _inTimerCallback), null, timeTillNextHour, new TimeSpan(0, 0, _reportFrequency, 0));
        }


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    if (_resetEvent != null)
                        _resetEvent.Dispose();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~ReportingService() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
