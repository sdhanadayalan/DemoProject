﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using PowerPositionReportService.Service;
using PowerPositionReportService.Autofac;
using System.Threading;
using log4net;

namespace PowerPositionReportService.Worker
{
    public class ReportWorker : IReportWorker
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private IReportingService _reportingService;

        public ReportWorker(IReportingService reportingService)
        {
            _reportingService = reportingService;
        }

        public void DoWork(BackgroundWorker worker, DoWorkEventArgs doWorkEventArgs)
        {
            Log.InfoFormat("Starting Report worker DoWork");
            _reportingService.GenerateAndScheduleDayAheadPowerPositionReport();
            while (!worker.CancellationPending )
            {
                if (_reportingService.ReportFailed)
                {
                    Log.InfoFormat("Restarting Report service");
                    _reportingService.Dispose();
                    if (!worker.CancellationPending)
                    {
                        _reportingService = AutofacInitialiser.GetService();
                        _reportingService.GenerateAndScheduleDayAheadPowerPositionReport();
                    }
                }
                else
                {
                    Thread.Sleep(500);
                }
            }

            if (_reportingService != null)
                _reportingService.Dispose();
            
        }


    }
}
