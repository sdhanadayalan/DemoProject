﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using System.Threading;
using System.ComponentModel;
using PowerPositionReportService.Worker;

namespace PowerPositionReportService
{
    public class ServiceController
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private readonly BackgroundWorker _worker;
        private bool _closePending;
        private readonly IReportWorker _reportWorker;

        public ServiceController(IReportWorker reportWorker)
        {
            _worker = new BackgroundWorker { WorkerSupportsCancellation = true };
            _worker.DoWork += WorkerOnDoWork;
            _worker.RunWorkerCompleted += WorkerOnRunWorkerCompleted;
            _reportWorker = reportWorker;
        }

        private void WorkerOnDoWork(object sender, DoWorkEventArgs doWorkEventArgs)
        {
            try
            {
                while (!_worker.CancellationPending)
                {
                    Log.Debug("Forcing garbage collection before mains service starts");
                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    _reportWorker.DoWork(_worker, doWorkEventArgs);
                    while (!_worker.CancellationPending)
                    {

                        Thread.Sleep(1000);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("An unexpected error in main service ", ex);
                throw;
            }
        }

        private void WorkerOnRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs args)
        {
            Log.Info("Background worker completed.");
            if (!_closePending && !args.Cancelled && !_worker.CancellationPending)
            {
                Log.Error($"Background worker died prematurely, restarting.");
                Thread.Sleep(5000);
                _worker.RunWorkerAsync();
            }
            else
            {
                //Dispose all objects
            }
        }

        public void OnStart()
        {
            Log.Info("Starting main service");
            try
            {
                _worker.RunWorkerAsync();
                Log.Info("Starting main started");
            }
            catch (Exception e)
            {
                Log.Error("error starting main service", e);
                throw;
            }
        }

        public void OnStop()
        {

            if (!_closePending)
            {
                Log.Info("Stopping main service");
                _closePending = true;


                _worker.CancelAsync();
                while (_worker.IsBusy)
                {
                    Thread.Sleep(500);
                }
                _closePending = false;
                Log.Info("Stopped main service");
            }
        }
    }
}