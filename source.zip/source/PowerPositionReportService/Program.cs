﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using System.Configuration;
using Topshelf;
using PowerPositionReportService.Autofac;
using Autofac;

namespace PowerPositionReportService
{
    class Program
    {
        private static ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        static void Main(string[] args)
        {
            System.IO.Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);
            AppDomain.CurrentDomain.UnhandledException += UnhandledExceptionOccurred;
            GlobalContext.Properties["LogDirectory"] = ConfigurationManager.AppSettings["LogDirectory"];

            Log.Info($"Starting {ConfigurationManager.AppSettings["ServiceName"]} Service");
            var container = AutofacInitialiser.BuildContainer();
            var service = container.Resolve<ServiceController>();
            
            HostFactory.Run(x =>
            {
                x.Service<ServiceController>(s =>
                {
                    s.ConstructUsing(name => service);
                    s.WhenStarted(tc => tc.OnStart());
                    s.WhenStopped(tc => tc.OnStop());
                });
                x.RunAsLocalSystem();
                x.SetServiceName(ConfigurationManager.AppSettings["ServiceName"]);
                x.SetDescription(ConfigurationManager.AppSettings["ServiceDescription"]);
                x.SetDisplayName(ConfigurationManager.AppSettings["ServiceDisplayName"]);
            });
        }

        private static void UnhandledExceptionOccurred(object sender, UnhandledExceptionEventArgs e)
        {
            var appName = sender as string;
            var ex = e.ExceptionObject as Exception;
            if (ex != null)
            {
                Log.Fatal($"Application: {appName ?? "<unknown>"} has caused an exception.", ex);
            }
        }
    }
}
