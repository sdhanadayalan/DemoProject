﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PowerCommon.Helpers;
using Services;
using System.IO;
using log4net;

namespace PowerPositionReportService.Reports
{
    public class ExportPowerPositionReport : IReport
    {
        private readonly string _reportPath;
        private readonly string _reportSuffix;
        private readonly string _reportPrefix;
        private readonly string _reportNamePattern;
        private readonly string _reportNumberFormat;
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public ExportPowerPositionReport(string reportPath,
            string reportSuffix,
            string reportPrefix,
            string reportNamePattern,
            string reportNumberFormat = "N"
            )
        {
            Log.Info("Creating ExportPowerPositionReport");
            _reportPath = reportPath;
            _reportSuffix = reportSuffix;
            _reportPrefix = reportPrefix;
            _reportNamePattern = reportNamePattern;
            _reportNumberFormat = reportNumberFormat;
        }

        public void ExportReport(PowerTrade powerTrade)
        {
            Log.Info("Starting ExportReport");
            if (!Directory.Exists(_reportPath))
            {
                Directory.CreateDirectory(_reportPath);
            }

            var fileName = $"{_reportPrefix}{DateTime.Now.ToString(_reportNamePattern)}.{_reportSuffix}";
            var seperator = ",";
            var header1 = "Local Time";
            var header2 = "Volume";
            Log.Info($"Exported filename :{fileName}");

            using (var file = new StreamWriter(_reportPath + Path.DirectorySeparatorChar + fileName))
            {
                try
                {
                    file.WriteLine($"{header1}{seperator}{header2}");
                    foreach(var a in powerTrade.Periods.OrderBy(p => TimePeriodHelper.GetSortOrder(p.Period)))
                    {
                        if ( a.Period == 25 && a.Volume  >= -0.001 && a.Volume <= 0.001)
                        {
                            continue;
                        }
                        file.WriteLine($"{TimePeriodHelper.GetDescription(a.Period)}{seperator}{a.Volume.ToString(_reportNumberFormat)}");
                    }
                }
                finally
                {
                    file.Close();
                }
            }


        }
    }
}
