﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using log4net;
using PowerPositionReportService.Service;
using PowerPositionReportService.Worker;
using PowerPositionReportService.Reports;
using System.Collections.Specialized;
using System.Configuration;
using Services;

namespace PowerPositionReportService.Autofac
{
    public static class AutofacInitialiser
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private static NameValueCollection ConfigSection;

        

        public static IContainer BuildContainer() 
        {
            ConfigSection = new NameValueCollection { ConfigurationManager.AppSettings };
            var builder = new ContainerBuilder();
            Register(builder);
            Container = builder.Build();
            return Container;
        }

        private static IContainer Container { get; set; }

        public static IReportingService GetService()
        {
            return Container.Resolve<IReportingService>();
        }

        internal static void Register(ContainerBuilder builder)
        {

            builder.Register(c => new PowerService())
                .As<IPowerService>();

            builder.Register(c => new ExportPowerPositionReport(
                reportPath: ConfigSection["ReportLocation"],
                reportPrefix: ConfigSection["FileNamePrefix"],
                reportNamePattern: ConfigSection["FileNamePattern"],
                reportSuffix: ConfigSection["FileNameSuffix"],
                reportNumberFormat: ConfigSection["reportNumberFormat"]

                ))
                .As<IReport>();

            builder.Register(c => new ReportingService(
                c.Resolve<IPowerService>(),
                c.Resolve<IReport>(), 
                reportFrequencyInMinutes: int.Parse( ConfigSection["reportFrequency"] )
                    ))
                .As<IReportingService>();
                

            builder.Register(c => new ReportWorker(c.Resolve<IReportingService>()))
                .As<IReportWorker>() ;

            builder.Register(c => new ServiceController(c.Resolve<IReportWorker>()))
            .As<ServiceController>()
            .SingleInstance();
        }

    }
}
