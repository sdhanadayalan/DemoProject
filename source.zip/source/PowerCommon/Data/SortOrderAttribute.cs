﻿using System;

namespace PowerCommon.Data
{
    [AttributeUsage(AttributeTargets.Field,AllowMultiple = false, Inherited = false)]
    public class SortOrderAttribute : Attribute
    {
        public SortOrderAttribute(int order)
        {
            SortOrder = order;
        }

        public int SortOrder { get; private set; }
    }
}
