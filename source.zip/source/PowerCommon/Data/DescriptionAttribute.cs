﻿using System;

namespace PowerCommon.Data
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false, Inherited = false)]
    public class DescriptionAttribute: Attribute
    {
        public DescriptionAttribute(string desc)
        {
            Description = desc;
        }

        public string Description { get; private set; }
    }
}
