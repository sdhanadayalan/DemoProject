﻿

namespace PowerCommon.Data
{
    public enum TimePeriod : int
    {
        [SortOrder(1), Description("23:00")]
        P1 = 1,
        [SortOrder(2), Description("00:00")]
        P2 = 2,
        [SortOrder(3), Description("01:00")]
        P3 = 3,
        [SortOrder(5), Description("02:00")]
        P4 = 4,
        [SortOrder(6), Description("03:00")]
        P5 = 5,
        [SortOrder(7), Description("04:00")]
        P6 = 6,
        [SortOrder(8), Description("05:00")]
        P7 = 7,
        [SortOrder(9), Description("06:00")]
        P8 = 8,
        [SortOrder(10), Description("07:00")]
        P9 = 9,
        [SortOrder(11), Description("08:00")]
        P10 = 10,
        [SortOrder(12), Description("09:00")]
        P11 = 11,
        [SortOrder(13), Description("10:00")]
        P12 = 12,
        [SortOrder(14), Description("11:00")]
        P13 = 13,
        [SortOrder(15), Description("12:00")]
        P14 = 14,
        [SortOrder(16), Description("13:00")]
        P15 = 15,
        [SortOrder(17), Description("14:00")]
        P16 = 16,
        [SortOrder(18), Description("15:00")]
        P17 = 17,
        [SortOrder(19), Description("16:00")]
        P18 = 18,
        [SortOrder(20), Description("17:00")]
        P19 = 19,
        [SortOrder(21), Description("18:00")]
        P20 = 20,
        [SortOrder(22), Description("19:00")]
        P21 = 21,
        [SortOrder(23), Description("20:00")]
        P22 = 22,
        [SortOrder(24), Description("21:00")]
        P23 = 23,
        [SortOrder(25), Description("22:00")]
        P24 = 24,
        [SortOrder(4), Description("01:00-DST")]
        P25 = 25,
    }


    
}
