﻿using System;
using System.Collections.Generic;
using System.Linq;
using PowerCommon.Data;

namespace PowerCommon.Helpers
{
    public static class TimePeriodHelper
    {
        private static readonly Dictionary<TimePeriod, int> TimePeriodToSortOrder = new Dictionary<TimePeriod, int>();
        private static readonly Dictionary<TimePeriod, string> TimePeriodToDesc = new Dictionary<TimePeriod, string>();

        private static readonly Dictionary<int, int> PeriodToSortOrder = new Dictionary<int, int>();
        private static readonly Dictionary<int, string> PeriodToDesc = new Dictionary<int, string>();


        static TimePeriodHelper()
        {
            var attributeVals = new List<string>();
            var enumType = typeof(TimePeriod);

            foreach (var val in Enum.GetValues(enumType))
            {
                var tpVal = (TimePeriod)val;
                var fieldInfo = enumType.GetField(tpVal.ToString());
                var descAttribs = fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];
                var sortAttribs = fieldInfo.GetCustomAttributes(typeof(SortOrderAttribute), false) as SortOrderAttribute[];

                TimePeriodToDesc.Add(tpVal, descAttribs[0].Description);
                TimePeriodToSortOrder.Add(tpVal, sortAttribs[0].SortOrder);

                PeriodToDesc.Add((int)tpVal, descAttribs[0].Description);
                PeriodToSortOrder.Add((int)tpVal, sortAttribs[0].SortOrder);


            }
        }

        public static int GetSortOrder(this TimePeriod timePeriod)
        {
            return TimePeriodToSortOrder[timePeriod];
        }

        public static string GetDescription(this TimePeriod timePeriod)
        {
            return TimePeriodToDesc[timePeriod];
        }

        public static int GetSortOrder(int period)
        {
            return PeriodToSortOrder[period];
        }

        public static string GetDescription(int period)
        {
            return PeriodToDesc[period];
        }

    }

}
