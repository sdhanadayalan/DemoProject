﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using Moq;
using Services;
using PowerPositionReportService.Reports;
using PowerPositionReportService.Service;

namespace UniteTests
{
    [TestFixture]
    public class ReportServiceTests
    {
        
        [SetUp]
        public void Init()
        {

        }

        [TearDown]
        public void TestsTearDown()
        {

        }

        [Test]
        public void TestPowerTradeCreate()
        {
            var trade = PowerTrade.Create(DateTime.Today, 25);

            Assert.IsNotNull(trade, "trade should not be null");
            Assert.IsNotNull(trade.Periods, "Periods attribute should not be null");
            Assert.AreEqual(25, trade.Periods.Count() );
            Assert.IsNotNull(trade.Periods[0]);
            for(int i = 0; i < 25; i++)
            {
                Assert.AreEqual(i +1, trade.Periods[i].Period);
                Assert.AreEqual(0, trade.Periods[i].Volume);
            }
        }

        [Test]
        public void TestPowerTradeGetTrades()
        {
            var service = new PowerService();
            var trades = service.GetTrades(DateTime.Today);
            Assert.IsNotNull(trades);
        }

        [Test]
        public void CheckTradeAggregation()
        {
            var pservice = new Mock<IPowerService>();
            var reportMock = new Mock<IReport>();
            var rservice = new ReportingService(pservice.Object, reportMock.Object, 1);
            pservice.Setup(p => p.GetTrades(It.IsAny<DateTime>())).Returns((DateTime date) =>
            {
                var trade1 = PowerTrade.Create(date, 24);
                var trade2 = PowerTrade.Create(date, 24);

                for(int i = 0; i < 24; i++)
                {
                    trade1.Periods[i].Volume = 100;
                }
                for (int i = 0; i < 11; i++)
                {
                    trade2.Periods[i].Volume = 50;
                }
                for (int i = 11; i < 24; i++)
                {
                    trade2.Periods[i].Volume = -20;
                }
                return new List<PowerTrade>{

                    trade1,
                    trade2
                };
            });

            reportMock.Setup(r => r.ExportReport(It.IsAny<PowerTrade>())).Callback((PowerTrade powerTrade) =>
            {
                Assert.IsNotNull(powerTrade);
                Assert.IsNotNull(powerTrade.Periods);
                Assert.AreEqual(25, powerTrade.Periods.Count());
                Assert.AreEqual(150, powerTrade.Periods[0].Volume);
                Assert.AreEqual(150, powerTrade.Periods[1].Volume);
                Assert.AreEqual(150, powerTrade.Periods[2].Volume);
                Assert.AreEqual(150, powerTrade.Periods[3].Volume);
                Assert.AreEqual(150, powerTrade.Periods[4].Volume);
                Assert.AreEqual(150, powerTrade.Periods[5].Volume);
                Assert.AreEqual(150, powerTrade.Periods[6].Volume);
                Assert.AreEqual(150, powerTrade.Periods[7].Volume);
                Assert.AreEqual(150, powerTrade.Periods[8].Volume);
                Assert.AreEqual(150, powerTrade.Periods[9].Volume);
                Assert.AreEqual(150, powerTrade.Periods[10].Volume);
                Assert.AreEqual(80, powerTrade.Periods[11].Volume);
                Assert.AreEqual(80, powerTrade.Periods[12].Volume);
                Assert.AreEqual(80, powerTrade.Periods[13].Volume);
                Assert.AreEqual(80, powerTrade.Periods[14].Volume);
                Assert.AreEqual(80, powerTrade.Periods[15].Volume);
                Assert.AreEqual(80, powerTrade.Periods[16].Volume);
                Assert.AreEqual(80, powerTrade.Periods[17].Volume);
                Assert.AreEqual(80, powerTrade.Periods[18].Volume);
                Assert.AreEqual(80, powerTrade.Periods[19].Volume);
                Assert.AreEqual(80, powerTrade.Periods[20].Volume);
                Assert.AreEqual(80, powerTrade.Periods[21].Volume);
                Assert.AreEqual(80, powerTrade.Periods[22].Volume);
                Assert.AreEqual(80, powerTrade.Periods[23].Volume);
            });
            rservice.GenerateDayAheadPowerPositionReport();
            reportMock.Verify(r => r.ExportReport(It.IsAny<PowerTrade>()), Times.Once);

        }

        
        [Test]
        public void CheckTradeAggregationWithfewPillers()
        {
            var pservice = new Mock<IPowerService>();
            var reportMock = new Mock<IReport>();
            var rservice = new ReportingService(pservice.Object, reportMock.Object, 1);

            pservice.Setup(p => p.GetTrades(It.IsAny<DateTime>())).Returns((DateTime date) =>
            {
                var trade1 = PowerTrade.Create(date, 4);
                var trade2 = PowerTrade.Create(date, 6);

                trade1.Periods[0].Volume = 50;
                trade1.Periods[1].Volume = -100;
                trade1.Periods[2].Volume = 200;
                trade1.Periods[3].Volume = 200;

                trade2.Periods[0].Volume = 50;
                trade2.Periods[1].Volume = -100;
                trade2.Periods[2].Volume = -100;
                trade2.Periods[3].Volume = -500;
                trade2.Periods[4].Volume = 50;

                return new List<PowerTrade>{

                    trade1,
                    trade2
                };
            });

            reportMock.Setup(r => r.ExportReport(It.IsAny<PowerTrade>())).Callback((PowerTrade powerTrade) =>
            {
                Assert.IsNotNull(powerTrade);
                Assert.IsNotNull(powerTrade.Periods);
                Assert.AreEqual(25, powerTrade.Periods.Count());
                Assert.AreEqual(100, powerTrade.Periods[0].Volume);
                Assert.AreEqual(-200, powerTrade.Periods[1].Volume);
                Assert.AreEqual(100, powerTrade.Periods[2].Volume);
                Assert.AreEqual(-300, powerTrade.Periods[3].Volume);
                Assert.AreEqual(50, powerTrade.Periods[4].Volume);
                Assert.AreEqual(0, powerTrade.Periods[5].Volume);
            });

            rservice.GenerateDayAheadPowerPositionReport();
            reportMock.Verify(r => r.ExportReport(It.IsAny<PowerTrade>()), Times.Once);
        }




    }
}
