﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using PowerCommon.Data;

namespace UnitTests
{
    [TestFixture]
    public class EnumerationTest
    {
        [SetUp]
        public void Init()
        {
            
        }

        [TearDown]
        public void TestsTearDown()
        {

        }

        [Test]
        public void CheckTimePeriodSortAttributeUnique()
        {

            var attributeVals = new List<int>();
            var enumType = typeof(TimePeriod);
            foreach(var val in Enum.GetValues(enumType))
            {
                var tpVal = (TimePeriod)val;
                var fieldInfo =  enumType.GetField(tpVal.ToString());
                var attribs = fieldInfo.GetCustomAttributes(typeof(SortOrderAttribute), false) as SortOrderAttribute[];

                Assert.IsNotNull(attribs, "enum should have SortOrderAttribute defined");
                Assert.IsTrue(attribs.Any(), "enum should have SortOrderAttribute defined");
                Assert.AreEqual(1, attribs.Count(), "There could be only one SortOrderAttribute");
                var sortVal = attribs[0];
                Assert.IsFalse(attributeVals.Contains(sortVal.SortOrder),"Sort order value should be unique");
                attributeVals.Add(sortVal.SortOrder);
            }
        }

        [Test]
        public void CheckTimePeriodDescriptionAttributeUnique()
        {

            var attributeVals = new List<string>();
            var enumType = typeof(TimePeriod);
            foreach (var val in Enum.GetValues(enumType))
            {
                var tpVal = (TimePeriod)val;
                var fieldInfo = enumType.GetField(tpVal.ToString());
                var attribs = fieldInfo.GetCustomAttributes(typeof(PowerCommon.Data.DescriptionAttribute), false) as PowerCommon.Data.DescriptionAttribute[];

                Assert.IsNotNull(attribs, "enum should have DescriptionAttribute defined");
                Assert.IsTrue(attribs.Any(), "enum should have DescriptionAttribute defined");
                Assert.AreEqual(1, attribs.Count(), "There could be only one DescriptionAttribute");
                var descVal = attribs[0];
                Assert.IsFalse(attributeVals.Contains(descVal.Description), "Description value should be unique");
                attributeVals.Add(descVal.Description);
            }
        }

        

        
    }
}
